package br.com.procedimentos;

public class Consulta {
	
	//
	private String dataConsulta;
	
	
	//
	public String getDataConsulta() {
		return dataConsulta;
	}

	public void setDataConsulta(String dataConsulta) {
		this.dataConsulta = dataConsulta;
	}
}
