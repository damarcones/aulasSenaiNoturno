package br.com.procedimentos;

public class MedicamentoPrescrito {

}
