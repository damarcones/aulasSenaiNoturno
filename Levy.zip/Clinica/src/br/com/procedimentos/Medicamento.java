package br.com.procedimentos;

public class Medicamento {
	
	//
	private String nomeMedicamento;
	
	
	//
	public String getNomeMedicamento() {
		return nomeMedicamento;
	}

	public void setNomeMedicamento(String nomeMedicamento) {
		this.nomeMedicamento = nomeMedicamento;
	}
}
