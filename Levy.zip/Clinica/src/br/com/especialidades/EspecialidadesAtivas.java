package br.com.especialidades;

public class EspecialidadesAtivas {

}
