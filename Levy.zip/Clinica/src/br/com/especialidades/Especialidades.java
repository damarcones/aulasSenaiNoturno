package br.com.especialidades;

public class Especialidades {
	
	//
	private String clinicaMedica;
	private String cardiologia;
	private String ortopedia;
	private String dermatologia;
	private String urologia;
	private String ginecologia;
	private String neurologia;
	private String psicologia;
	private String psiquiatria;
	private String pediatria;
	
	
	//
	public String getClinicaMedica() {
		return clinicaMedica;
	}
	public void setClinicaMedica(String clinicaMedica) {
		this.clinicaMedica = clinicaMedica;
	}
	public String getCardiologia() {
		return cardiologia;
	}
	public void setCardiologia(String cardiologia) {
		this.cardiologia = cardiologia;
	}
	public String getOrtopedia() {
		return ortopedia;
	}
	public void setOrtopedia(String ortopedia) {
		this.ortopedia = ortopedia;
	}
	public String getDermatologia() {
		return dermatologia;
	}
	public void setDermatologia(String dermatologia) {
		this.dermatologia = dermatologia;
	}
	public String getUrologia() {
		return urologia;
	}
	public void setUrologia(String urologia) {
		this.urologia = urologia;
	}
	public String getGinecologia() {
		return ginecologia;
	}
	public void setGinecologia(String ginecologia) {
		this.ginecologia = ginecologia;
	}
	public String getNeurologia() {
		return neurologia;
	}
	public void setNeurologia(String neurologia) {
		this.neurologia = neurologia;
	}
	public String getPsicologia() {
		return psicologia;
	}
	public void setPsicologia(String psicologia) {
		this.psicologia = psicologia;
	}
	public String getPsiquiatria() {
		return psiquiatria;
	}
	public void setPsiquiatria(String psiquiatria) {
		this.psiquiatria = psiquiatria;
	}
	public String getPediatria() {
		return pediatria;
	}
	public void setPediatria(String pediatria) {
		this.pediatria = pediatria;
	}
	
}
