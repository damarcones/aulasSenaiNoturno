package br.com.pessoas;

public class Medico extends Paciente {
	//
	private String numeroCrm;
	
	
	//
	public String getNumeroCrm() {
		return numeroCrm;
	}

	public void setNumeroCrm(String numeroCrm) {
		this.numeroCrm = numeroCrm;
	}
	
	
}
